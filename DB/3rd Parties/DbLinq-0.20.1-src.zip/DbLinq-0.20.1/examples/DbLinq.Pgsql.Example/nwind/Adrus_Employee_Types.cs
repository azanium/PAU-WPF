﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AndrusDB
{
    public class HourlyEmployee : Employee
    {
    }

    public class SalariedEmployee : Employee
    {
    }

    public class CommissionedEmployee : Employee
    {
    }

}
