﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace nwind
{
    /// <summary>
    /// for testing of enum handling - used from AllTypes mysql table.
    /// </summary>
    public enum DbLinq_EnumTest
    {
        AA, BB, CC, DD
    }
}
