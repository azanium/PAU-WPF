drop user linquser;\p\g
COMMIT;\p\g
create user linquser with privileges=(createdb);
COMMIT;\p\g
\q
