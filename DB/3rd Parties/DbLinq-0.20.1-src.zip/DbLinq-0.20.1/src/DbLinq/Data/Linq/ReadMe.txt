﻿DbLinq.Data.Linq folder contains Linq to SQL compliant interfaces and classes, plus their extensions (format to be defined)
